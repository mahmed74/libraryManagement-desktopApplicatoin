# easyUML for Netbeans-8.2 & Netbeans-11.0 & Netbeans-12.0
Includes easyUML plug-in .nbm files

Installation video link:
https://www.youtube.com/watch?v=KaUtssmQs6A
